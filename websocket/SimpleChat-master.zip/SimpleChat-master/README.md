project name : SimpleChat
- @author Dev. Mk
- Default setting with Spring4 MVC Project +  WebSocKet
- Coustom Chatting
